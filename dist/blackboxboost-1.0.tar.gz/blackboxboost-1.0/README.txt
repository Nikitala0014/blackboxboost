Description
===========

Library for machine learning automation based on gradient boosting, meta-learning, 
bayesian optimization, as well as an ensemble of the best parameters obtained in the bayesian optimization.